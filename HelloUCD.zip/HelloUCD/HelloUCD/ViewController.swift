//
//  ViewController.swift
//  HelloUCD
//
//  Created by shelob on 29/02/2020.
//  Copyright © 2020 COMP47390. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

